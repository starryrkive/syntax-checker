# parser.py

import ply.yacc as yacc
from lexer import tokens

syntax_error_flag = False

def p_program(p):
    '''program : statement
               | statement program
               | empty'''

def p_statement(p):
    '''statement : switch_statement
                 | array_declaration SEMICOLON
                 | function_call SEMICOLON
                 | for_loop_statement
                 | ID EQUAL expression SEMICOLON
                 | BREAK SEMICOLON'''

# --- Switch Statement ---
def p_switch_statement(p):
    '''switch_statement : SWITCH LPAREN expression RPAREN LBRACE case_list RBRACE'''

def p_case_list(p):
    '''case_list : case_statement
                 | case_statement case_list'''

def p_case_statement(p):
    '''case_statement : CASE expression COLON statement_block
                      | DEFAULT COLON statement_block'''

def p_statement_block(p):
    '''statement_block : statement
                       | statement statement_block
                       | empty'''

# --- Array Declaration ---
def p_array_declaration(p):
    '''array_declaration : VAR ID EQUAL LBRACKET element_list RBRACKET
                         | CONST ID EQUAL LBRACKET element_list RBRACKET
                         | LET ID EQUAL LBRACKET element_list RBRACKET
                         | VAR ID EQUAL NEW ID LPAREN NUMBER RPAREN'''

def p_element_list(p):
    '''element_list : expression
                    | expression COMMA element_list
                    | empty'''

# --- Function Call ---
def p_function_call(p):
    '''function_call : ID LPAREN argument_list RPAREN'''

def p_argument_list(p):
    '''argument_list : expression
                     | expression COMMA argument_list
                     | empty'''

# --- For Loop ---
def p_for_loop_statement(p):
    '''for_loop_statement : FOR LPAREN for_init SEMICOLON for_condition SEMICOLON for_update RPAREN LBRACE statement_block RBRACE'''

def p_for_init(p):
    '''for_init : declaration_or_assignment
                | empty'''

def p_for_condition(p):
    '''for_condition : expression LESSTHAN expression
                     | empty'''

def p_for_update(p):
    '''for_update : ID PLUS PLUS
                  | ID MINUS MINUS
                  | assignment_expression
                  | empty'''
                  
# --- Auxiliary Rules ---
def p_declaration_or_assignment(p):
    '''declaration_or_assignment : VAR ID EQUAL expression
                                 | assignment_expression'''

def p_assignment_expression(p):
    '''assignment_expression : ID EQUAL expression'''

def p_expression(p):
    '''expression : expression PLUS term
                  | expression MINUS term
                  | term'''

def p_term(p):
    '''term : ID
            | NUMBER
            | STRING
            | function_call
            | LPAREN expression RPAREN'''

# --- Error and Empty Rules ---
def p_empty(p):
    'empty :'
    pass

def p_error(p):
    global syntax_error_flag
    syntax_error_flag = True # <--- Sets the flag on error
    
    if p:
        print(f"Syntax error at token '{p.type}' ('{p.value}') on line {p.lineno}")
    else:
        print("Syntax error at EOF")

# Build the parser
parser = yacc.yacc()