# lexer.py

import ply.lex as lex

# --- Token List ---
tokens = (
    # Reserved Keywords
    'SWITCH', 'CASE', 'DEFAULT', 'BREAK',
    'VAR', 'CONST', 'LET', 'FOR', 'NEW',
    
    # Operators and Punctuation
    'SEMICOLON', 'COLON', 'COMMA', 'LPAREN', 'RPAREN',
    'LBRACE', 'RBRACE', 'LBRACKET', 'RBRACKET',
    'EQUAL', 'PLUS', 'MINUS', 'LESSTHAN', 

    # Literals/Identifiers
    'ID', 'NUMBER', 'STRING',
)

# --- Reserved Words Dictionary ---
reserved = {
    'switch': 'SWITCH',
    'case': 'CASE',
    'default': 'DEFAULT',
    'break': 'BREAK',
    'var': 'VAR',
    'const': 'CONST',
    'let': 'LET',
    'for': 'FOR',
    'new': 'NEW',
}

# --- Regular Expressions for simple tokens ---
t_SEMICOLON = r';'
t_COLON     = r':'
t_COMMA     = r','
t_LPAREN    = r'\('
t_RPAREN    = r'\)'
t_LBRACE    = r'\{'
t_RBRACE    = r'\}'
t_LBRACKET  = r'\['
t_RBRACKET  = r'\]'
t_EQUAL     = r'='
t_PLUS      = r'\+'
t_MINUS     = r'-'
t_LESSTHAN  = r'<'

# --- Regular Expressions with action code ---

def t_ID(t):
    r'[a-zA-Z_$][a-zA-Z_0-9$]*'
    t.type = reserved.get(t.value, 'ID')
    return t

def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_STRING(t):
    r'\"[^"]*\"'
    return t

# Single-line comment: Discarded by returning nothing
def t_SINGLE_COMMENT(t):
    r'//.*'
    pass

# Ignore rule for whitespace and tabs
t_ignore = ' \t'

# Newlines
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Error handling rule
def t_error(t):
    print(f"Illegal character '{t.value[0]}' at line {t.lexer.lineno}")
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()