# test_harness.py

import sys
from lexer import lexer
# We need to import the parser module itself to access the global flag
import parser 

def run_evaluation(description, code):
    """Runs a single code snippet through the PLY parser and reports the result."""
    
    # Reset the error flag before parsing
    parser.syntax_error_flag = False
    
    # Reset lexer state for new input
    lexer.lineno = 1
    
    # Run the parser
    # We call the 'parser' object inside the imported 'parser' module
    parser.parser.parse(code, lexer=lexer) 
    
    # Check the flag status and print the summary
    if parser.syntax_error_flag:
        result_summary = "No" # Rejected
        print("❌ Result: Failed (Syntax Error Detected)")
    else:
        result_summary = "Yes" # Accepted
        print("✅ Result: Accepted (Syntax OK)")
        
    print(f"Test Result (Yes/No): {result_summary}")

def run_test_suite(tests):
    """Runs all predefined tests."""
    print("🔧 Running Predefined JavaScript Syntax Tests...")
    
    for i, (desc, code) in enumerate(tests, 1):
        print(f"\n🧩 Test {i}: {desc}")
        print(f"Code: {code.strip()}")
        run_evaluation(desc, code)
        print("--------------------------------------------------")

def main_interactive():
    """Manages the full program flow, including the persistent interactive session."""
    
    TESTS = [
        ("Switch Statement", 'switch(x){case 1: break; default: break;}'),
        ("Comment", '// This comment is handled by the lexer'),
        ("Array Declaration", 'let arr = [10, "hello", 30];'),
        ("Function Call", 'myFunc(a + 5, 2);'),
        ("For Loop", 'for (var k = 0; k < 10; k++) { total = total + 1; }'),
        ("Syntax Error: Missing Colon", 'switch(y){case 2 console.log("error");}'),
    ]

    # --- Step 1: Run the automated tests ---
    run_test_suite(TESTS)

    # --- Step 2: Persistent Loop for custom input ---
    print("\n--- Custom Code Evaluation Session ---")
    
    # Loop until the user explicitly says 'no'
    while True:
        try:
            user_choice = input("Do you want to enter a custom code snippet? (yes/no): ").strip().lower()
            
            if user_choice in ('no', 'n'):
                print("\nEvaluation complete. Goodbye!")
                break
                
            elif user_choice in ('yes', 'y'):
                print("\nEnter your single line of JavaScript code below (e.g., const val = 'new';):")
                custom_code = input(">>> ").strip()
                
                if custom_code:
                    print("\n--- Evaluating Custom Input ---")
                    print(f"Code: {custom_code}")
                    run_evaluation("Custom User Input", custom_code)
                    print("-----------------------------")
                else:
                    print("No code entered. Please try again.")
            
            else:
                print("Invalid input. Please enter 'yes' or 'no'.")
                
        except EOFError:
            print("\nInput stream closed. Exiting.")
            break
        except Exception as e:
            print(f"\nAn unexpected error occurred: {e}")
            break

if __name__ == '__main__':
    main_interactive()